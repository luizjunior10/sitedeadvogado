
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { MessageSquare, Send, X, Bot, User } from 'lucide-react';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const Assistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant', text: string }[]>([
    { role: 'assistant', text: "Olá! Sou o assistente virtual do Dr. Luiz Carlos. Em que posso te ajudar hoje sobre sua aposentadoria ou benefício?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          { role: 'user', parts: [{ text: userMsg }] }
        ],
        config: {
          systemInstruction: "Você é um assistente virtual para o Dr. Luiz Carlos, um advogado especializado em Direito Previdenciário. Seu objetivo é ajudar potenciais clientes com dúvidas básicas sobre aposentadoria (idade, tempo de serviço, especial), BPC/LOAS e auxílio-doença. Seja profissional, acolhedor e sempre lembre que a análise final e detalhada deve ser feita pelo Dr. Luiz Carlos. Se o usuário quiser agendar ou falar com o advogado, forneça o número (11) 9.6312.8396 ou recomende clicar no botão de WhatsApp da página. Mantenha as respostas curtas e objetivas.",
          temperature: 0.7,
        }
      });

      const text = response.text || "Desculpe, tive um pequeno problema. Poderia repetir?";
      setMessages(prev => [...prev, { role: 'assistant', text }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'assistant', text: "Houve um erro na comunicação. Por favor, tente novamente em instantes ou chame diretamente no WhatsApp." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-24 right-6 z-40">
      {isOpen ? (
        <div className="bg-white rounded-2xl shadow-2xl w-80 md:w-96 flex flex-col overflow-hidden border border-slate-200">
          <div className="bg-indigo-900 text-white p-4 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Bot size={20} />
              <span className="font-semibold">Assistente Previdenciário</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:bg-indigo-800 p-1 rounded">
              <X size={20} />
            </button>
          </div>
          
          <div ref={scrollRef} className="h-96 overflow-y-auto p-4 space-y-4 bg-slate-50">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${m.role === 'user' ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-white text-slate-700 shadow-sm rounded-tl-none border border-slate-100'}`}>
                  {m.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white p-3 rounded-2xl shadow-sm rounded-tl-none border border-slate-100 animate-pulse text-slate-400 text-sm">
                  Pensando...
                </div>
              </div>
            )}
          </div>
          
          <div className="p-3 bg-white border-t border-slate-100 flex gap-2">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Digite sua dúvida..."
              className="flex-grow bg-slate-100 border-none rounded-lg px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500"
            />
            <button 
              onClick={handleSend}
              disabled={isLoading}
              className="bg-indigo-600 text-white p-2 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-indigo-900 text-white flex items-center gap-2 px-4 py-3 rounded-full shadow-lg hover:bg-indigo-800 transition-all border-4 border-white"
        >
          <MessageSquare size={20} />
          <span className="font-semibold">Tirar Dúvidas Online</span>
        </button>
      )}
    </div>
  );
};

export default Assistant;
